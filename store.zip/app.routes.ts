import { Component } from '@angular/core';
import { Routes } from '@angular/router';
import { AdminComponent } from './admin/admin.component';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { StoreRegistrationComponent } from './store-registration/store-registration.component';

export const routes: Routes = [
  { path: 'home', component: AppComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'employee', component: EmployeeComponent },
  { path: 'registration', component: StoreRegistrationComponent },
];

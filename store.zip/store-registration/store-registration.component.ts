import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import {
  FormBuilder,
  FormGroup,
  FormControl,
  Validators,
  FormsModule,
  ReactiveFormsModule,
} from '@angular/forms';

@Component({
  selector: 'app-store-registration',
  standalone: true,
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './store-registration.component.html',
  styleUrl: './store-registration.component.css',
})
export class StoreRegistrationComponent {
  storeName: string = '';
  storeAddress = '';

  registerStore() {
    // Call API to register the store
  }
}

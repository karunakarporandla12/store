import { Component } from '@angular/core';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee/employee.model';

@Component({
  selector: 'app-admin-employee',
  templateUrl: './admin-employee.component.html',
  styleUrls: ['./admin-employee.component.css']
})
export class AdminEmployeeComponent {
  employees: Employee[] = [];
  newEmployee: Employee = { id: 0, name: '', designation: '' };

  constructor(private employeeService: EmployeeService) { }

  ngOnInit(): void {
    this.loadEmployees();
  }

  loadEmployees() {
    this.employeeService.getEmployees().subscribe(
      employees => this.employees = employees,
      error => console.error(error)
    );
  }

  createEmployee() {
    this.employeeService.createEmployee(this.newEmployee).subscribe(
      () => {
        this.loadEmployees();
        this.newEmployee = { id: 0, name: '', designation: '' };
      },
      error => console.error(error)
    );
  }
}

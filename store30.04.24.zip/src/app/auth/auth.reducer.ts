// auth.reducer.ts
import { createReducer, on } from '@ngrx/store';
import * as AuthActions from './auth.actions';
import { AuthState } from './auth.state';

export const initialState: AuthState = {
  isAuthenticated: false,
  userRole: null,
};

export const authReducer = createReducer(
  initialState,
  on(AuthActions.login, (state) => ({ ...state, isAuthenticated: true })),
  on(AuthActions.logout, (state) => ({
    ...state,
    isAuthenticated: false,
    userRole: null,
  })),
  on(AuthActions.setUserRole, (state, { role }) => ({
    ...state,
    userRole: role,
  }))
);

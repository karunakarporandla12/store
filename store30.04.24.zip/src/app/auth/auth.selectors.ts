// auth.selectors.ts

import { createSelector } from '@ngrx/store';
import { AppState } from '../app.state';
import { AuthState } from './auth.state';

export const selectAuthState = (state: AppState) => state.auth;

export const selectIsAuthenticated = createSelector(
  selectAuthState,
  (auth: AuthState) => auth?.isAuthenticated // Ensure auth.isAuthenticated exists
);

export const selectUserRole = createSelector(
  selectAuthState,
  (auth) => auth.userRole // Ensure auth.userRole exists
);

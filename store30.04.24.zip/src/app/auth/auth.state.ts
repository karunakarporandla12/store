import { UserRole } from '../user/user.model';

// auth.state.ts
export interface AuthState {
  isAuthenticated: boolean;
  userRole: UserRole | null;
}

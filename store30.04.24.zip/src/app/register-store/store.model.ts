// store.model.ts
export interface Store {
    id: string;
    name: string;
    address: string;
    location: string;
  }
  
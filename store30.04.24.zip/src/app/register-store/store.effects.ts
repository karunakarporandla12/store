// store.effects.ts
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { StoreService } from './store.service'; // Implement this service to interact with API
import { addStore } from './store.actions';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { of } from 'rxjs';

@Injectable()
export class StoreEffects {
  //   addStore$ = createEffect(() => this.actions$.pipe(
  //     ofType(addStore),
  //     mergeMap(({ store }) => this.storeService.addStore(store).pipe(
  //       map(() => ({ type: 'Store Added Successfully' })),
  //       catchError(() => of({ type: 'Store Add Error' }))
  //     ))
  //   ));

  constructor(private actions$: Actions) // private storeService: StoreService
  {}
}

// store.state.ts
import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { Store } from './store.model';

export interface StoreState extends EntityState<Store> {}

export const storeAdapter = createEntityAdapter<Store>();

export const initialState: StoreState = storeAdapter.getInitialState();

export const {
  selectIds: selectStoreIds,
  selectEntities: selectStoreEntities,
  // selectAll: selectAllStores,
  selectTotal: selectTotalStores,
} = storeAdapter.getSelectors();

export const selectStoreState = createFeatureSelector<StoreState>('stores');

// export const selectAllStores = createSelector(
  // selectStoreState,
  // selectAllStores
// );
// 
// store.actions.ts
import { createAction, props } from '@ngrx/store';
import { Store } from './store.model';

export const addStore = createAction('[Store] Add Store', props<{ store: Store }>());

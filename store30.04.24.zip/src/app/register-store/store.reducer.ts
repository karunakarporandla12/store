// store.reducer.ts
import { createReducer, on } from '@ngrx/store';
import { addStore } from './store.actions';
import { initialState, storeAdapter } from './store.state';

export const storeReducer = createReducer(
  initialState,
  on(addStore, (state, { store }) => {
    return storeAdapter.addOne(store, state);
  })
);

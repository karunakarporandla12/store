// store.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Store } from './store.model';

@Injectable({
  providedIn: 'root'
})
export class StoreService {
  private apiUrl = 'https://example.com/api/stores'; // API endpoint

  constructor(private http: HttpClient) { }

  addStore(store: Store): Observable<any> {
    return this.http.post(this.apiUrl, store);
  }
}

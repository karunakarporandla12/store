import { Component, NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StoreService } from '../store.service';
import { Store, StoreModule } from '@ngrx/store';
// import { AppState } from '../register-store/store.actions';
import { addStore } from '../register-store/store.actions';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { EffectsModule } from '@ngrx/effects';
import { storeReducer } from './store.reducer';
import { StoreEffects } from './store.effects';

@Component({
  selector: 'app-register-store',
  standalone: true,
  imports: [FormsModule, BrowserModule, HttpClientModule,
    BrowserModule,
    HttpClientModule,
    // StoreModule.forRoot({ stores: storeReducer }),
    // EffectsModule.forRoot([StoreEffects])
   ],
  templateUrl: './register-store.component.html',
  styleUrl: './register-store.component.css',
})
export class RegisterStoreComponent {
  // store: Store = { id: 0, name: '', address: '', location: '' };

  // constructor(private store: Store<AppState>) {}

  registerStore() {
    // this.store.dispatch(addStore({ store: this.store }));
  }
}

// admin-employee.state.ts
import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { Employee } from '../employee/employee.model';

export interface AdminEmployeeState extends EntityState<Employee> {
  loading: boolean;
  error: any;
}

export const adapter = createEntityAdapter<Employee>();

export const initialState: AdminEmployeeState = adapter.getInitialState({
  loading: false,
  error: null,
});

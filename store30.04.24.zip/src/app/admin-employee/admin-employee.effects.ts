import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { mergeMap, catchError, map } from 'rxjs/operators';
import * as EmployeeActions from '../admin-employee/admin-employee.actions';
import { of } from 'rxjs';
import { EmployeeService } from '../employee.service'; // Import and implement this service

@Injectable()
export class EmployeeEffects {

  createEmployee$ = createEffect(() => this.actions$.pipe(
    ofType(EmployeeActions.createEmployee),
    mergeMap(({ employee }) => this.employeeService.createEmployee(employee).pipe(
      map(() => ({ type: '[Employee] Create Employee Success' })),
      catchError(() => of({ type: '[Employee] Create Employee Failure' }))
    ))
  ));

  constructor(
    private actions$: Actions,
    private employeeService: EmployeeService
  ) {}
}
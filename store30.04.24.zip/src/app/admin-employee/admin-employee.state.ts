import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { Employee } from '../employee/employee.model';

export interface EmployeeState extends EntityState<Employee> {
  employees: any;
  loading: boolean; // Indicate loading state
  error: any; // Hold error information if any
} // employee.state.ts
// import { EntityState, createEntityAdapter } from '@ngrx/entity';
// import { Employee } from '../employee/employee.model';

export interface EmployeeState extends EntityState<Employee> {
  loading: boolean;
  error: any;
  employeests: any; // Adjust the type according to your needs
}

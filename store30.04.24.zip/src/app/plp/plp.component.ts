import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Product } from '../product-upload/product.model';
import { ProductService } from '../products/product.service';

@Component({
  selector: 'app-plp',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './plp.component.html',
  styleUrl: './plp.component.css',
})
export class PlpComponent {
  products: Product[] = [];
  errorMessage: string = '';

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.getProducts();
  }

  getProducts() {
    this.productService.getProducts().subscribe((res) => {
      this.products = res;
    });
  }
}

import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';
import { AppState } from '../app.state';
import * as AuthActions from '../auth/auth.actions'; // Import all actions from auth.actions file
import { selectIsAuthenticated } from '../auth/auth.selectors';
import { UserRole } from '../user/user.model';
import { UserService } from '../user/user.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [ReactiveFormsModule, FormsModule, CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
})
export class LoginComponent implements OnInit {
  isAuthenticated!: Observable<boolean>;
  // isAuthenticated = this.store.pipe(select(selectIsAuthenticated));

  // constructor(private store: Store<AppState>) {}
  username: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(
    private store: Store<AppState>,
    private router: Router,
    private userService: UserService
  ) {}
  ngOnInit() {
    this.isAuthenticated = this.store.pipe(select(selectIsAuthenticated));
  }

  login() {
    // Call the service to check user data in db.json
    // this.userService.getUser(this.username, this.password).subscribe((user) => {
    //   if (user) {
    //     console.log('who is user coming', user);
    //     this.store.dispatch(AuthActions.login());
    //     this.router.navigate(['/dashboard']);
    //     console.log('user logged in sucessfully');
    //   } else {
    //     // Show error message if user does not exist
    //     this.errorMessage = 'Invalid username or password.';
    //   }
    // });
    this.userService.getUser(this.username, this.password).subscribe((user) => {
      if (user) {
        // Dispatch login action if user exists
        this.store.dispatch(AuthActions.login());
        // Redirect user based on role
        switch (user.role) {
          case UserRole.Supervisor:
            this.router.navigate(['/productupload']);
            break;
          case UserRole.Seller:
            this.router.navigate(['/plp']);
            break;
          default:
            // Redirect to dashboard or other default route for other roles
            this.router.navigate(['/dashboard']);
            break;
        }
      } else {
        // Show error message if user does not exist
        this.errorMessage = 'Invalid username or password.';
      }
    });
  }
}

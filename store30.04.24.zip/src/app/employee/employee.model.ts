export interface Employee {
  id: number;
  name: string;
  designation: string; // e.g., 'Superwiser', 'Seller'
}

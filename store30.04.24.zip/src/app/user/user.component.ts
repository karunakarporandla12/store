import { BrowserModule } from '@angular/platform-browser';
import { Component, NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import { userReducer } from './user.reducer';
import { UserEffects } from './user.effects';
import { Store } from '@ngrx/store';
import { AppState } from '../app.state';
import { addUser } from './user.actions';
import { User, UserRole } from './user.model';

@Component({
  selector: 'app-user',
  standalone: true,
  imports: [BrowserModule, HttpClientModule],
  templateUrl: './user.component.html',
  styleUrl: './user.component.css',
})
export class UserComponent {
  newUser: User = { id: 0, username: '', role: UserRole.Admin };

  constructor(private store: Store<AppState>) {}

  registerUser() {
    this.store.dispatch(addUser({ user: this.newUser }));
    this.newUser = { id: 0, username: '', role: UserRole.Admin };
  }
}

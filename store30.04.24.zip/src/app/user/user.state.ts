// user.state.ts
import { EntityState, createEntityAdapter } from '@ngrx/entity';
import { User } from './user.model';

export interface UserState extends EntityState<User> {}

export const userAdapter = createEntityAdapter<User>();

export const initialState: UserState = userAdapter.getInitialState();

// user.effects.ts
import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { mergeMap, catchError, map } from 'rxjs/operators';
import { of } from 'rxjs';
import { UserService } from '../user/user.service';
import * as UserActions from './user.actions';

@Injectable()
export class UserEffects {
  addUser$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UserActions.addUser),
      mergeMap(({ user }) =>
        this.userService.addUser(user).pipe(
          map(() => ({ type: 'User Added Successfully' })),
          catchError(() => of({ type: 'User Add Error' }))
        )
      )
    )
  );

  constructor(private actions$: Actions, private userService: UserService) {}
}

// user.service.ts
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, map, Observable, of } from 'rxjs';
import { User } from './user.model';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  private apiUrl = 'http://localhost:3000/users'; // API endpoint

  constructor(private http: HttpClient) {}

  addUser(user: User): Observable<any> {
    return this.http.post(this.apiUrl, user);
  }
  getUser(username: string, password: string): Observable<any> {
    // Assuming 'db.json' contains user data
    return this.http.get<any[]>(this.apiUrl).pipe(
      map((users) =>
        users.find(
          (user) => user.username === username && user.password === password
        )
      ),
      catchError(() => of(null))
    );
  }
}

// user.model.ts
export interface User {
    id: number;
    username: string;
    role: UserRole;
  }
  
  export enum UserRole {
    Admin = 'admin',
    Supervisor = 'supervisor',
    Seller = 'seller'
  }
  
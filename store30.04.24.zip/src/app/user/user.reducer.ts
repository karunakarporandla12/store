// user.reducer.ts
import { createReducer, on } from '@ngrx/store';
import { userAdapter, initialState } from './user.state';
import * as UserActions from './user.actions';

export const userReducer = createReducer(
  initialState,
  on(UserActions.addUser, (state, { user }) => {
    return userAdapter.addOne(user, state);
  })
);

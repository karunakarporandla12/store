// app.state.ts

import { AuthState } from './auth/auth.state'; // Import AuthState interface from auth.state file
// import { UserState } from './user.state';

export interface AppState {
  auth: AuthState;
  // Other state properties if any
}

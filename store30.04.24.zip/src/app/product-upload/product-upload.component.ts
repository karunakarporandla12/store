import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProductService } from '../products/product.service';
import { Product } from './product.model';

@Component({
  selector: 'app-product-upload',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule, FormsModule],
  templateUrl: './product-upload.component.html',
  styleUrl: './product-upload.component.css',
})
export class ProductUploadComponent {
  product: Product = { id: 0, name: '', price: 0, image: '', tax: 0 };
  errorMessage: string = '';
  productImage: any;

  constructor(private productService: ProductService) {}

  uploadProduct() {
    this.productService.uploadProduct(this.product).subscribe(
      () => {
        this.product = { id: 0, name: '', price: 0, image: '', tax: 0 };
      },
      (error) => {
        this.errorMessage = 'Failed to upload product. Please try again.';
        console.error(error);
      }
    );
  }

  onFileChange(event: any) {
    if (event.target.files && event.target.files.length > 0) {
      this.productImage = event.target.files[0];
    }
  }
}
// import { CommonModule } from '@angular/common';
// import { Component } from '@angular/core';
// import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// import { ProductService } from '../products/product.service';
// import { Product } from './product.model';
// import { Store } from '@ngrx/store';
// import { AppState } from '../app.state';
// import * as ProductActions from '../products/product.actions';
// @Component({
//   selector: 'app-product-upload',
//   standalone: true,
//   imports: [ReactiveFormsModule, CommonModule, FormsModule],
//   templateUrl: './product-upload.component.html',
//   styleUrl: './product-upload.component.css',
// })
// export class ProductUploadComponent {
//   product: Product = {
//     id: 0,
//     name: '',
//     price: 0,
//     image: '',
//     tax: 0,
//   };
//   imageFile: File | null = null;

//   constructor(private store: Store<AppState>) {}

//   onFileSelected(event: any) {
//     this.imageFile = event.target.files[0];
//   }

//   uploadProduct() {
//     const formData = new FormData();
//     formData.append('id', String(this.product.id));
//     formData.append('name', this.product.name);
//     formData.append('price', String(this.product.price));
//     // formData.append('image', this.imageFile);
//     formData.append('tax', String(this.product.tax));
//     if (this.imageFile) {
//       formData.append('image', this.imageFile);
//     }

//     this.store.dispatch(ProductActions.uploadProduct({ product: formData }));
//     console.log('product uploaded', this.product);
//     this.product = { id: 0, name: '', price: 0, image: '', tax: 0 }; // Reset the form after submission
//     this.imageFile = null;
//   }
// }

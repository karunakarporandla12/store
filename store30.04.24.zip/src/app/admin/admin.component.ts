import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { routes } from '../app.routes';
// import { BrowserModule } from '@angular/platform-browser';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee/employee.model';

@Component({
  selector: 'app-admin',
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, HttpClientModule, CommonModule],
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css',
})
export class AdminComponent {
  employees: Employee[] = [];
  newEmployee: Employee = { id: 0, name: '', designation: '' };

  constructor(private router: Router) {}

  AddEmployee() {
    this.router.navigate(['/admin-employee']);
  }
}

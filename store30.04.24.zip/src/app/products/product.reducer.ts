import { createReducer, on } from '@ngrx/store';
import { Product } from '../product-upload/product.model';
import * as ProductActions from './product.actions';

export interface ProductState {
  products: Product[];
  selectedProductId: number | null;
}

export const initialState: ProductState = {
  products: [],
  selectedProductId: null,
};

export const productReducer = createReducer(
  initialState,
  on(ProductActions.setProducts, (state, { products }) => ({
    ...state,
    products,
  })),
  on(ProductActions.selectProduct, (state, { productId }) => ({
    ...state,
    selectedProductId: productId,
  }))
);

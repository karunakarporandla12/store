// product.service.ts

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from '../product-upload/product.model';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  private apiUrl = 'http://localhost:3000/products'; // Assuming 'api' is the base URL for API endpoints

  constructor(private http: HttpClient) {}

  uploadProduct(product: Product): Observable<any> {
    return this.http.post(this.apiUrl, product);
  }
  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.apiUrl);
  }
}

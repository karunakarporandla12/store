import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Product } from '../product-upload/product.model';
import { ProductService } from './product.service';

@Component({
  selector: 'app-products',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './products.component.html',
  styleUrl: './products.component.css',
})
export class ProductsComponent implements OnInit {
  products: Product[] = [];
  errorMessage: string = '';

  constructor(private productService: ProductService) {}

  ngOnInit(): void {
    this.getProducts();
  }

  getProducts() {
    this.productService.getProducts().subscribe(res=>{
      this.products=res;
    })
    // this.productService.getProducts().subscribe(
    //   (products: any) => {
    //     this.products = products;
    //   }

      // (error) => {
      //   this.errorMessage = 'Failed to fetch products. Please try again.';
      //   console.error(error);
      // }
  //   );
  // }
  }
}

// product.actions.ts

import { createAction, props } from '@ngrx/store';
import { Product } from '../product-upload/product.model';

export const uploadProduct = createAction(
  '[Product Upload] Upload Product',
  props<{ product: FormData }>()
);

export const loadProducts = createAction('[Product List] Load Products');

export const setProducts = createAction(
  '[Product List] Set Products',
  props<{ products: Product[] }>()
);

export const selectProduct = createAction(
  '[Product Details] Select Product',
  props<{ productId: any }>()
);

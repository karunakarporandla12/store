import { Component } from '@angular/core';
import { Routes } from '@angular/router';
import { AdminEmployeeComponent } from './admin-employee/admin-employee.component';
import { AdminComponent } from './admin/admin.component';
import { AppComponent } from './app.component';
import { AuthGuard, RoleGuard } from './auth/auth.guard';
import { DashboardComponent } from './dashboard/dashboard.component';
import { EmployeeComponent } from './employee/employee.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { PlpComponent } from './plp/plp.component';
import { ProductUploadComponent } from './product-upload/product-upload.component';
import { ProductsComponent } from './products/products.component';
import { RegisterStoreComponent } from './register-store/register-store.component';
import { UserRole } from './user/user.model';

export const routes: Routes = [
  { path: 'login', component: LoginComponent },
  {
    path: 'dashboard',
    component: DashboardComponent,
    // canActivate: [AuthGuard],
  },
  { path: 'home', component: HomeComponent },
  {
    path: 'admin',
    component: AdminComponent,
    // canActivate: [AuthGuard, RoleGuard],
    // data: { role: UserRole.Admin },
  },
  { path: 'employee', component: EmployeeComponent },
  {
    path: 'register-store',
    component: RegisterStoreComponent,
    outlet: 'register-store',
  },
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'admin-employee', component: AdminEmployeeComponent },
  { path: 'productupload', component: ProductUploadComponent },
  { path: 'products', component: ProductsComponent },
  { path: 'plp', component: PlpComponent },
];

import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class StoreService {
  private baseUrl = 'http://localhost:3000'; // Assuming Json server is running on port 3000

  constructor(private http: HttpClient) {}

  registerStore(storeData: any) {
    return this.http.post(`${this.baseUrl}/stores`, storeData);
  }
}

import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { StoreService } from '../store.service';
// import {HTTPClient} from '../'

@Component({
  selector: 'app-register-store',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './register-store.component.html',
  styleUrl: './register-store.component.css',
})
export class RegisterStoreComponent {
  storeName: any;
  registrationNumber: any;
  location: any;
  constructor(private storeService: StoreService) {}

  registerStore() {
    // Get form values
    const storeData = {
      storeName: this.storeName,
      registrationNumber: this.registrationNumber,
      location: this.location,
    };

    // Call service to register store
    this.storeService.registerStore(storeData).subscribe(
      (response) => {
        console.log('Store registered successfully');
      },
      (error) => {
        console.error('Error registering store:', error);
      }
    );
  }
}

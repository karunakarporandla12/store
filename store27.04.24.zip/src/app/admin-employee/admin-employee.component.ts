import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { EmployeeService } from '../employee.service';
import { Employee } from '../employee/employee.model';
import { loadEmployees, createEmployee } from './admin-employee.actions';
import {
  selectEmployees,
  selectLoading,
  selectError,
} from './admin-employee.selectors';
import { FormsModule, NgForm, ReactiveFormsModule } from '@angular/forms';
import {
  HttpBackend,
  HttpClientModule,
  HttpXhrBackend,
  provideHttpClient,
} from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { Observer } from 'rxjs';
@Component({
  selector: 'app-admin-employee',
  templateUrl: './admin-employee.component.html',
  styleUrls: ['./admin-employee.component.css'],
  standalone: true,
  imports: [FormsModule, ReactiveFormsModule, HttpClientModule, CommonModule],
  providers: [
    {
      provide: HttpBackend,
      useClass: HttpXhrBackend, // Use HttpXhrBackend which uses fetch API by default
    },
    // provideHttpClient().withFetch(),
  ],
})
export class AdminEmployeeComponent implements OnInit {
  employees$: Observable<Employee[]> = new Observable<Employee[]>();
  loading$: Observable<boolean> = new Observable<boolean>();
  error$!: Observable<any>; // Definite assignment assertion
  newEmployee: Employee = { id: 0, name: '', designation: '' };

  constructor(private employeeService: EmployeeService, private store: Store) {}

  ngOnInit(): void {
    this.store.dispatch(loadEmployees());
    this.employees$ = this.store.select(selectEmployees);
    this.loading$ = this.store.select(selectLoading);
    this.error$ = this.store.select(selectError);
    this.loadEmployees();
  }

  loadEmployees() {
    this.employeeService.getEmployees().subscribe(
      (employees) => (this.employees$ = of(employees)), // Wrap employees array in an Observable using 'of' operator
      (error) => console.error(error)
    );
  }

  createEmployee() {
    this.store.dispatch(createEmployee({ employee: this.newEmployee }));
    this.newEmployee = { id: 0, name: '', designation: '' };
  }
  // createEmployee() {
  //   // Check if name and designation are provided
  //   if (!this.newEmployee.name || !this.newEmployee.designation) {
  //     console.error('Name and designation are required.');
  //     return;
  //   }

  //   // Call the service method to create an employee
  //   this.employeeService.createEmployee(this.newEmployee).subscribe({
  //     next: (createdEmployee: Employee) => {
  //       console.log('Employee created:', createdEmployee);
  //       this.loadEmployees(); // Refresh the list of employees
  //       this.newEmployee = { id: 0, name: '', designation: '' }; // Clear the form
  //     },
  //     error: (error) => console.error('Error creating employee:', error),
  //   });
  // }
}

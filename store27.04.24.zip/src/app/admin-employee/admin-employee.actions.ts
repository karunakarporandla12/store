// employee.actions.ts
import { createAction, props } from '@ngrx/store';
// import { Employee } from './employee.model';
import { Employee } from '../employee/employee.model';

export const loadEmployees = createAction('[Employee] Load Employees');
export const employeesLoaded = createAction(
  '[Employee] Employees Loaded',
  props<{ employees: Employee[] }>()
);
export const createEmployee = createAction(
  '[Employee] Create Employee',
  props<{ employee: Employee }>()
);
export const employeeCreated = createAction(
  '[Employee] Employee Created',
  props<{ employee: Employee }>()
);
export const employeeError = createAction(
  '[Employee] Employee Error',
  props<{ error: any }>()
);

// employee.reducer.ts
import { createReducer, on } from '@ngrx/store';
import { Employee } from '../employee/employee.model';
import * as EmployeeActions from './admin-employee.actions';

export interface EmployeeState {
  employees: Employee[];
  loading: boolean;
  error: any;
}

export const initialState: EmployeeState = {
  employees: [],
  loading: false,
  error: null,
};

export const employeeReducer = createReducer(
  initialState,
  on(EmployeeActions.loadEmployees, (state) => ({ ...state, loading: true })),
  on(EmployeeActions.employeesLoaded, (state, { employees }) => ({
    ...state,
    employees,
    loading: false,
  })),
  on(EmployeeActions.createEmployee, (state) => ({ ...state, loading: true })),
  on(EmployeeActions.employeeCreated, (state, { employee }) => ({
    ...state,
    employees: [...state.employees, employee],
    loading: false,
  })),
  on(EmployeeActions.employeeError, (state, { error }) => ({
    ...state,
    error,
    loading: false,
  }))
);

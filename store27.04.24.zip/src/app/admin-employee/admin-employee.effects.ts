// employee.effects.ts
import { Injectable } from '@angular/core';
import { Actions, ofType, createEffect } from '@ngrx/effects';
import { of } from 'rxjs';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { EmployeeService } from '../employee.service';
import * as EmployeeActions from './admin-employee.actions';

@Injectable()
export class EmployeeEffects {
  loadEmployees$ = createEffect(() =>
    this.actions$.pipe(
      ofType(EmployeeActions.loadEmployees),
      mergeMap(() =>
        this.employeeService.getEmployees().pipe(
          map((employees) => EmployeeActions.employeesLoaded({ employees })),
          catchError((error) => of(EmployeeActions.employeeError({ error })))
        )
      )
    )
  );

  createEmployee$ = createEffect(() =>
    this.actions$.pipe(
      ofType(EmployeeActions.createEmployee),
      mergeMap(({ employee }) =>
        this.employeeService.createEmployee(employee).pipe(
          map(() => EmployeeActions.employeeCreated({ employee })),
          catchError((error) => of(EmployeeActions.employeeError({ error })))
        )
      )
    )
  );

  constructor(
    private actions$: Actions,
    private employeeService: EmployeeService
  ) {}
}

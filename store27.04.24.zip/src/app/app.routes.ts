import { Component } from '@angular/core';
import { Routes } from '@angular/router';
import { AdminEmployeeComponent } from './admin-employee/admin-employee.component';
import { AdminComponent } from './admin/admin.component';
import { AppComponent } from './app.component';
import { EmployeeComponent } from './employee/employee.component';
import { RegisterStoreComponent } from './register-store/register-store.component';

export const routes: Routes = [
  { path: 'home', component: AppComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'employee', component: EmployeeComponent },
  {
    path: 'register-store',
    component: RegisterStoreComponent,
    outlet: 'register-store',
  },
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'admin-employee', component: AdminEmployeeComponent },
];

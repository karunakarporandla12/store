// import { Component } from '@angular/core';
// import { FormsModule } from '@angular/forms';
// import { StoreService } from '../store.service';
// // import {}

// @Component({
//   selector: 'app-store-registration',
//   templateUrl: './store-registration.component.html',
//   styleUrls: ['./store-registration.component.css'],
//   standalone: true,
//   imports: [FormsModule],
// })
// export class StoreRegistrationComponent {
//   storeName: any;
//   registrationNumber: any;
//   location: any;
//   constructor(private storeService: StoreService) {}

//   registerStore() {
//     // Get form values
//     const storeData = {
//       storeName: this.storeName,
//       registrationNumber: this.registrationNumber,
//       location: this.location,
//     };

//     // Call service to register store
//     this.storeService.registerStore(storeData).subscribe(
//       (response) => {
//         console.log('Store registered successfully');
//         // Optionally, you can redirect to a success page or perform other actions
//       },
//       (error) => {
//         console.error('Error registering store:', error);
//       }
//     );
//   }
// }
